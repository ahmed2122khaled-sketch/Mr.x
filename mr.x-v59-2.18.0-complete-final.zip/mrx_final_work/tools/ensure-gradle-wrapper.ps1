$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Jar = Join-Path $Root 'gradle\wrapper\gradle-wrapper.jar'
if (Test-Path $Jar) {
    $length = (Get-Item $Jar).Length
    if ($length -gt 1024) { exit 0 }
    Remove-Item $Jar -Force
}
& (Join-Path $Root 'tools\fetch-gradle-wrapper.ps1')
