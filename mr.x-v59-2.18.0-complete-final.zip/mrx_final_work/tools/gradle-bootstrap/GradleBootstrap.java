import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/**
 * Offline-friendly bootstrap used only when the official Gradle Wrapper JAR
 * has not yet been fetched. It downloads and verifies the pinned Gradle
 * distribution, extracts it into the Gradle user cache, then delegates all
 * arguments to Gradle. The normal CI path still replaces this bootstrap with
 * Gradle's official wrapper JAR before building.
 */
public final class GradleBootstrap {
    private static final String VERSION = "9.7.1";
    private static final String URL = "https://services.gradle.org/distributions/gradle-9.7.1-bin.zip";
    private static final String SHA256 = "acd53f1edaf02f1a8ff99879f8a34b302661a057d9b063ae9e35b552f804d20a";

    public static void main(String[] args) throws Exception {
        Path project = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path home = Paths.get(System.getProperty("user.home"));
        Path base = home.resolve(".gradle").resolve("wrapper").resolve("dists").resolve("mr-x-gradle-" + VERSION);
        Path zip = base.resolve("gradle-" + VERSION + "-bin.zip");
        Path dist = base.resolve("gradle-" + VERSION);
        Path gradle = dist.resolve("bin").resolve(isWindows() ? "gradle.bat" : "gradle");

        Files.createDirectories(base);
        if (!Files.isRegularFile(gradle)) {
            if (!Files.isRegularFile(zip) || !SHA256.equalsIgnoreCase(sha256(zip))) {
                Files.deleteIfExists(zip);
                System.err.println("Downloading Gradle " + VERSION + " distribution...");
                download(URL, zip);
                String actual = sha256(zip);
                if (!SHA256.equalsIgnoreCase(actual)) {
                    Files.deleteIfExists(zip);
                    throw new IOException("Gradle distribution SHA-256 mismatch. Expected " + SHA256 + ", got " + actual);
                }
            }
            extract(zip, base);
            if (!Files.isRegularFile(gradle)) {
                throw new IOException("Gradle distribution extracted, but executable was not found: " + gradle);
            }
        }

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/c");
            command.add(gradle.toString());
        } else {
            command.add(gradle.toString());
        }
        Collections.addAll(command, args);

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(project.toFile());
        pb.inheritIO();
        pb.environment().putIfAbsent("GRADLE_USER_HOME", home.resolve(".gradle").toString());
        Process p = pb.start();
        System.exit(p.waitFor());
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static void download(String url, Path out) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setRequestProperty("User-Agent", "MR-X-Gradle-Bootstrap/1.0");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("Gradle download failed with HTTP " + code);
        try (InputStream in = c.getInputStream(); OutputStream outStream = Files.newOutputStream(out)) {
            byte[] buf = new byte[1024 * 128];
            int n;
            while ((n = in.read(buf)) >= 0) outStream.write(buf, 0, n);
        } finally {
            c.disconnect();
        }
    }

    private static String sha256(Path p) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(p)) {
            byte[] buf = new byte[1024 * 128];
            int n;
            while ((n = in.read(buf)) >= 0) md.update(buf, 0, n);
        }
        StringBuilder s = new StringBuilder();
        for (byte b : md.digest()) s.append(String.format(Locale.ROOT, "%02x", b));
        return s.toString();
    }

    private static void extract(Path zip, Path base) throws Exception {
        String root = null;
        try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry e;
            byte[] buf = new byte[1024 * 128];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                if (name.isEmpty() || name.startsWith("/") || name.contains("../") || name.contains("..\\"))
                    throw new IOException("Unsafe Gradle archive entry: " + name);
                int slash = name.indexOf('/');
                if (slash > 0 && root == null) root = name.substring(0, slash);
                Path target = base.resolve(name).normalize();
                if (!target.startsWith(base)) throw new IOException("Archive traversal detected: " + name);
                if (e.isDirectory()) Files.createDirectories(target);
                else {
                    Files.createDirectories(target.getParent());
                    try (OutputStream out = Files.newOutputStream(target)) {
                        int n;
                        while ((n = zin.read(buf)) >= 0) out.write(buf, 0, n);
                    }
                }
                zin.closeEntry();
            }
        }
        if (root == null) throw new IOException("Empty Gradle distribution archive");
        if (!root.equals("gradle-" + VERSION)) {
            Path actual = base.resolve(root);
            Path expected = base.resolve("gradle-" + VERSION);
            if (Files.exists(expected)) deleteTree(expected);
            Files.move(actual, expected, StandardCopyOption.REPLACE_EXISTING);
        }
        Files.deleteIfExists(zip);
    }

    private static void deleteTree(Path p) throws IOException {
        if (!Files.exists(p)) return;
        try (var s = Files.walk(p)) {
            s.sorted(Comparator.reverseOrder()).forEach(x -> {
                try { Files.deleteIfExists(x); } catch (IOException ex) { throw new UncheckedIOException(ex); }
            });
        } catch (UncheckedIOException e) { throw e.getCause(); }
    }
}
