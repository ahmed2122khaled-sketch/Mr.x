-- mr.x / SocialNetworkAndroid
-- Complete Supabase foundation schema for a fresh project.
-- Generated from the Android client's REST contract.

create extension if not exists pgcrypto;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 1 and 32),
  display_name text not null check (char_length(display_name) between 1 and 100),
  bio text check (bio is null or char_length(bio) <= 2000),
  avatar_url text,
  cover_url text,
  website text check (website is null or char_length(website) <= 500),
  location text check (location is null or char_length(location) <= 120),
  is_verified boolean not null default false,
  is_private boolean not null default false,
  followers_count integer not null default 0 check (followers_count >= 0),
  following_count integer not null default 0 check (following_count >= 0),
  posts_count integer not null default 0 check (posts_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text,
  media_urls jsonb not null default '[]'::jsonb,
  media_type text,
  likes_count integer not null default 0 check (likes_count >= 0),
  comments_count integer not null default 0 check (comments_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_url text not null,
  media_type text not null,
  caption text,
  views_count integer not null default 0 check (views_count >= 0),
  expires_at timestamptz not null default (now() + interval '24 hours'),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint follows_not_self check (follower_id <> following_id),
  constraint follows_unique_pair unique (follower_id, following_id)
);

create table if not exists public.likes (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint likes_unique_pair unique (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text,
  media_url text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('like','comment','follow','message')),
  actor_id uuid references public.profiles(id) on delete set null,
  post_id uuid references public.posts(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete cascade,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- Updated-at triggers.
drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists posts_set_updated_at on public.posts;
create trigger posts_set_updated_at before update on public.posts
for each row execute function public.set_updated_at();

drop trigger if exists comments_set_updated_at on public.comments;
create trigger comments_set_updated_at before update on public.comments
for each row execute function public.set_updated_at();

drop trigger if exists conversations_set_updated_at on public.conversations;
create trigger conversations_set_updated_at before update on public.conversations
for each row execute function public.set_updated_at();

-- Create a profile automatically for every new Auth user.
create or replace function public.handle_new_user()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
declare
  base_username text;
  candidate text;
  suffix integer := 0;
  display text;
begin
  display := coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), split_part(coalesce(new.email, 'user'), '@', 1));
  base_username := lower(regexp_replace(coalesce(split_part(new.email, '@', 1), 'user'), '[^a-zA-Z0-9_]+', '_', 'g'));
  base_username := left(nullif(base_username, ''), 24);
  if base_username is null or length(base_username) < 3 then base_username := 'user_' || left(replace(new.id::text, '-', ''), 8); end if;
  candidate := base_username;
  while exists (select 1 from public.profiles where username = candidate) loop
    suffix := suffix + 1;
    candidate := left(base_username, 24 - length(suffix::text) - 1) || '_' || suffix::text;
  end loop;
  insert into public.profiles(id, username, display_name)
  values (new.id, candidate, left(display, 100))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Counter maintenance.
create or replace function public.sync_follow_counts()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.profiles set following_count = following_count + 1 where id = new.follower_id;
    update public.profiles set followers_count = followers_count + 1 where id = new.following_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.profiles set following_count = greatest(0, following_count - 1) where id = old.follower_id;
    update public.profiles set followers_count = greatest(0, followers_count - 1) where id = old.following_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists follows_counter on public.follows;
create trigger follows_counter after insert or delete on public.follows
for each row execute function public.sync_follow_counts();

create or replace function public.sync_post_count()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.profiles set posts_count = posts_count + 1 where id = new.user_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.profiles set posts_count = greatest(0, posts_count - 1) where id = old.user_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists posts_counter on public.posts;
create trigger posts_counter after insert or delete on public.posts
for each row execute function public.sync_post_count();

create or replace function public.sync_like_count()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set likes_count = likes_count + 1 where id = new.post_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.posts set likes_count = greatest(0, likes_count - 1) where id = old.post_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists likes_counter on public.likes;
create trigger likes_counter after insert or delete on public.likes
for each row execute function public.sync_like_count();

create or replace function public.sync_comment_count()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set comments_count = comments_count + 1 where id = new.post_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.posts set comments_count = greatest(0, comments_count - 1) where id = old.post_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists comments_counter on public.comments;
create trigger comments_counter after insert or delete on public.comments
for each row execute function public.sync_comment_count();

create or replace function public.touch_conversation_from_message()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  update public.conversations set updated_at = now() where id = new.conversation_id;
  return new;
end;
$$;

drop trigger if exists messages_touch_conversation on public.messages;
create trigger messages_touch_conversation after insert on public.messages
for each row execute function public.touch_conversation_from_message();

-- Notifications for the actions the Android client exposes.
create or replace function public.notify_like()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
declare owner_id uuid;
begin
  select user_id into owner_id from public.posts where id = new.post_id;
  if owner_id is not null and owner_id <> new.user_id then
    insert into public.notifications(user_id,type,actor_id,post_id)
    values(owner_id,'like',new.user_id,new.post_id);
  end if;
  return new;
end;
$$;

drop trigger if exists likes_notification on public.likes;
create trigger likes_notification after insert on public.likes
for each row execute function public.notify_like();

create or replace function public.notify_comment()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
declare owner_id uuid;
begin
  select user_id into owner_id from public.posts where id = new.post_id;
  if owner_id is not null and owner_id <> new.user_id then
    insert into public.notifications(user_id,type,actor_id,post_id,comment_id)
    values(owner_id,'comment',new.user_id,new.post_id,new.id);
  end if;
  return new;
end;
$$;

drop trigger if exists comments_notification on public.comments;
create trigger comments_notification after insert on public.comments
for each row execute function public.notify_comment();

create or replace function public.notify_follow()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
begin
  insert into public.notifications(user_id,type,actor_id)
  values(new.following_id,'follow',new.follower_id);
  return new;
end;
$$;

drop trigger if exists follows_notification on public.follows;
create trigger follows_notification after insert on public.follows
for each row execute function public.notify_follow();

-- RLS-safe membership helper. Security-definer avoids recursive policies on conversation_members.
create or replace function public.is_conversation_member(p_conversation_id uuid, p_user_id uuid default auth.uid())
returns boolean
security definer
set search_path = public
language sql
stable
as $$
  select exists (
    select 1 from public.conversation_members
    where conversation_id = p_conversation_id and user_id = p_user_id
  );
$$;

revoke all on function public.is_conversation_member(uuid, uuid) from public;
grant execute on function public.is_conversation_member(uuid, uuid) to authenticated;

-- Direct-message conversation RPC used by MainActivity.
create or replace function public.create_direct_conversation(p_other_user_id uuid)
returns uuid
security definer
set search_path = public
language plpgsql
as $$
declare
  me uuid := auth.uid();
  existing_id uuid;
  new_id uuid;
begin
  if me is null then raise exception 'not authenticated'; end if;
  if p_other_user_id is null or p_other_user_id = me then raise exception 'invalid recipient'; end if;
  if not exists (select 1 from public.profiles where id = p_other_user_id) then raise exception 'recipient not found'; end if;

  select c.id into existing_id
  from public.conversations c
  where (select count(*) from public.conversation_members cm where cm.conversation_id = c.id) = 2
    and exists (select 1 from public.conversation_members cm where cm.conversation_id = c.id and cm.user_id = me)
    and exists (select 1 from public.conversation_members cm where cm.conversation_id = c.id and cm.user_id = p_other_user_id)
  limit 1;

  if existing_id is not null then return existing_id; end if;

  insert into public.conversations default values returning id into new_id;
  insert into public.conversation_members(conversation_id,user_id) values (new_id,me),(new_id,p_other_user_id);
  return new_id;
end;
$$;

revoke all on function public.create_direct_conversation(uuid) from public;
grant execute on function public.create_direct_conversation(uuid) to authenticated;

-- Indexes for the native client's hot paths.
create index if not exists profiles_created_at_idx on public.profiles(created_at desc);
create index if not exists profiles_username_idx on public.profiles(username);
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_created_idx on public.posts(user_id, created_at desc);
create index if not exists stories_active_idx on public.stories(expires_at, created_at desc);
create index if not exists stories_user_created_idx on public.stories(user_id, created_at desc);
create index if not exists follows_follower_idx on public.follows(follower_id, created_at desc);
create index if not exists follows_following_idx on public.follows(following_id, created_at desc);
create index if not exists likes_post_idx on public.likes(post_id, created_at desc);
create index if not exists comments_post_idx on public.comments(post_id, created_at asc);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
create index if not exists messages_conversation_idx on public.messages(conversation_id, created_at asc);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id, conversation_id);

create or replace function public.notify_message()
returns trigger
security definer
set search_path = public
language plpgsql
as $$
declare recipient uuid;
begin
  for recipient in
    select cm.user_id from public.conversation_members cm
    where cm.conversation_id = new.conversation_id and cm.user_id <> new.sender_id
  loop
    insert into public.notifications(user_id,type,actor_id)
    values(recipient,'message',new.sender_id);
  end loop;
  return new;
end;
$$;

drop trigger if exists messages_notification on public.messages;
create trigger messages_notification after insert on public.messages
for each row execute function public.notify_message();

-- RLS.
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.stories enable row level security;
alter table public.follows enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (not is_private or id = auth.uid());
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists posts_select on public.posts;
create policy posts_select on public.posts for select to authenticated using (true);
drop policy if exists posts_insert on public.posts;
create policy posts_insert on public.posts for insert to authenticated with check (user_id = auth.uid());
drop policy if exists posts_update on public.posts;
create policy posts_update on public.posts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists posts_delete on public.posts;
create policy posts_delete on public.posts for delete to authenticated using (user_id = auth.uid());

drop policy if exists stories_select on public.stories;
create policy stories_select on public.stories for select to authenticated using (expires_at > now() or user_id = auth.uid());
drop policy if exists stories_insert on public.stories;
create policy stories_insert on public.stories for insert to authenticated with check (user_id = auth.uid());
drop policy if exists stories_update on public.stories;
create policy stories_update on public.stories for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists stories_delete on public.stories;
create policy stories_delete on public.stories for delete to authenticated using (user_id = auth.uid());

drop policy if exists follows_select on public.follows;
create policy follows_select on public.follows for select to authenticated using (true);
drop policy if exists follows_insert on public.follows;
create policy follows_insert on public.follows for insert to authenticated with check (follower_id = auth.uid());
drop policy if exists follows_delete on public.follows;
create policy follows_delete on public.follows for delete to authenticated using (follower_id = auth.uid());

drop policy if exists likes_select on public.likes;
create policy likes_select on public.likes for select to authenticated using (true);
drop policy if exists likes_insert on public.likes;
create policy likes_insert on public.likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists likes_delete on public.likes;
create policy likes_delete on public.likes for delete to authenticated using (user_id = auth.uid());

drop policy if exists comments_select on public.comments;
create policy comments_select on public.comments for select to authenticated using (true);
drop policy if exists comments_insert on public.comments;
create policy comments_insert on public.comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists comments_update on public.comments;
create policy comments_update on public.comments for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists comments_delete on public.comments;
create policy comments_delete on public.comments for delete to authenticated using (user_id = auth.uid());

drop policy if exists conversations_select on public.conversations;
create policy conversations_select on public.conversations for select to authenticated using (public.is_conversation_member(id, auth.uid()));

drop policy if exists conversation_members_select on public.conversation_members;
create policy conversation_members_select on public.conversation_members for select to authenticated using (public.is_conversation_member(conversation_id, auth.uid()));

drop policy if exists messages_select on public.messages;
create policy messages_select on public.messages for select to authenticated using (public.is_conversation_member(messages.conversation_id, auth.uid()));
drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert to authenticated with check (sender_id = auth.uid() and public.is_conversation_member(messages.conversation_id, auth.uid()));
drop policy if exists messages_update on public.messages;
create policy messages_update on public.messages for update to authenticated using (public.is_conversation_member(messages.conversation_id, auth.uid())) with check (public.is_conversation_member(messages.conversation_id, auth.uid()));

drop policy if exists notifications_select on public.notifications;
create policy notifications_select on public.notifications for select to authenticated using (user_id = auth.uid());
drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Public media bucket used by the Android client. Upload/delete remain user-scoped.
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do update set public = excluded.public;

drop policy if exists media_upload_own on storage.objects;
create policy media_upload_own on storage.objects for insert to authenticated
with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists media_update_own on storage.objects;
create policy media_update_own on storage.objects for update to authenticated
using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists media_delete_own on storage.objects;
create policy media_delete_own on storage.objects for delete to authenticated
using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
