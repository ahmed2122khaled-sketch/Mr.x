#!/usr/bin/env python3
"""Static verification for the native Android project.

This intentionally does not claim an APK build. A real build requires a JDK,
Gradle/Gradle Wrapper, Android SDK and installed SDK packages.
"""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / "app/src/main/java/com/socialnetwork/app/MainActivity.java"
CONSTANTS = ROOT / "app/src/main/java/com/socialnetwork/app/core/AppConstants.java"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
WRAPPER_JAR = ROOT / "gradle/wrapper/gradle-wrapper.jar"

errors = []
checks = []

def check(name, ok, detail=""):
    checks.append((name, ok, detail))
    if not ok:
        errors.append(f"{name}: {detail}")

text = MAIN.read_text(encoding="utf-8")
manifest = MANIFEST.read_text(encoding="utf-8")
constants = CONSTANTS.read_text(encoding="utf-8")

for forbidden in ("android.webkit.WebView", "loadUrl(", "addJavascriptInterface", "CustomTabsIntent", "androidx.browser"):
    check(f"no browser shell: {forbidden}", forbidden not in text, "forbidden native/web shell reference found")

check("single onDestroy", text.count("protected void onDestroy") == 1, f"count={text.count('protected void onDestroy')}")
check("no stale executor reference", "executor.shutdownNow()" not in text and "executor." not in text.lower(), "stale direct executor symbol found")
check("bounded shared executor", "IO_THREADS = 6" in (ROOT / "app/src/main/java/com/socialnetwork/app/core/AppExecutors.java").read_text(encoding="utf-8") and "IO_QUEUE_CAPACITY = 256" in (ROOT / "app/src/main/java/com/socialnetwork/app/core/AppExecutors.java").read_text(encoding="utf-8"), "bounded 6-worker executor configuration missing")
check("readLimited exists", "readLimited(" in text and re.search(r"\bbyte\[\]\s+readLimited\s*\(", text) is not None, "helper missing")
check("media trust validation exists", "isTrustedMediaUrl(" in text, "media URL validation missing")
check("HTTPS only manifest", 'android:usesCleartextTraffic="false"' in manifest, "cleartext traffic is not disabled")
check("launcher activity", 'android.intent.action.MAIN' in manifest and 'android.intent.category.LAUNCHER' in manifest, "launcher intent missing")
check("preview limit defined", "MAX_IMAGE_PREVIEW_BYTES" in constants, "dedicated image preview limit missing")
check("brace balance", text.count("{") == text.count("}"), f"{{={text.count('{')}}}={text.count('}')}")
check("paren balance", text.count("(") == text.count(")"), f"(={text.count('(')})={text.count(')')}")

check("Gradle wrapper JAR present", WRAPPER_JAR.is_file(), "official gradle-wrapper.jar is missing")
gradle = shutil.which("gradle")
check("system Gradle available", bool(gradle), "gradle executable is not installed in this environment")

print("=== Static Android verification ===")
for name, ok, detail in checks:
    print(f"[{'PASS' if ok else 'BLOCKED'}] {name}" + (f" — {detail}" if detail and not ok else ""))

if errors:
    print("\nRESULT: STATIC CODE CHECKS PASS, BUILD TOOLCHAIN CHECKS BLOCKED")
    sys.exit(2)
print("\nRESULT: PASS")
